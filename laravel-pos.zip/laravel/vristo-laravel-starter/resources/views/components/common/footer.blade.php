<div class="dark:text-white-dark text-center ltr:sm:text-left rtl:sm:text-right p-6 mt-auto">© <span id="footer-year">2022</span>.
    Vristo All rights reserved.</div>
