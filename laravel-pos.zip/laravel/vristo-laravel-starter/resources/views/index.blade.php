<x-layout.default>
    <div>
        <h1>starter page</h1>
    </div>
</x-layout.default>
