<?= $this->extend('components/layout/default.php') ?>

<?= $this->section('content') ?>

<div>
    <h1>starter page</h1>
</div>


<?= $this->endSection() ?>